package com.cartr.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

public class CartrClient implements ClientModInitializer {
    private static KeyBinding openMenuKey;

    public static boolean fpsOptimizer = false;
    public static boolean potatoMode = false;
    public static boolean rainbowHud = true;
    public static boolean playerHitboxes = false;
    public static boolean rainbowNametags = true;

    private static PerformanceSnapshot savedSettings;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cartr_client.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.cartr_client"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new CartrMenuScreen());
                }
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            if (rainbowHud) renderRainbowHud(drawContext);
        });

        WorldRenderEvents.AFTER_ENTITIES.register(CartrClient::renderRainbowNametags);
    }

    /**
     * Applies the selected profile to Minecraft's actual client graphics options.
     * Potato Mode takes priority if both toggles are enabled.
     */
    public static void refreshPerformanceSettings() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.options == null) return;

        if (!fpsOptimizer && !potatoMode) {
            if (savedSettings != null) {
                savedSettings.restore(client);
                savedSettings = null;
                client.options.write();
            }
            return;
        }

        if (savedSettings == null) {
            savedSettings = new PerformanceSnapshot(client);
        }

        if (potatoMode) {
            applyPotatoProfile(client);
        } else {
            applyFpsProfile(client);
        }
        client.options.write();
    }

    private static void applyFpsProfile(MinecraftClient client) {
        client.options.getViewDistance().setValue(6);
        client.options.getSimulationDistance().setValue(5);
        client.options.getParticles().setValue(ParticlesMode.DECREASED);
        client.options.getClouds().setValue(CloudRenderMode.FAST);
        client.options.getGraphicsMode().setValue(GraphicsMode.FAST);
        client.options.getEntityShadows().setValue(false);
        client.options.getSmoothLighting().setValue(false);
        client.options.getMipmapLevels().setValue(1);
        client.options.getEntityDistanceScaling().setValue(0.75);
    }

    private static void applyPotatoProfile(MinecraftClient client) {
        client.options.getViewDistance().setValue(2);
        client.options.getSimulationDistance().setValue(2);
        client.options.getParticles().setValue(ParticlesMode.MINIMAL);
        client.options.getClouds().setValue(CloudRenderMode.OFF);
        client.options.getGraphicsMode().setValue(GraphicsMode.FAST);
        client.options.getEntityShadows().setValue(false);
        client.options.getSmoothLighting().setValue(false);
        client.options.getMipmapLevels().setValue(0);
        client.options.getBiomeBlendRadius().setValue(0);
        client.options.getEntityDistanceScaling().setValue(0.5);
    }

    private static final class PerformanceSnapshot {
        private final int viewDistance;
        private final int simulationDistance;
        private final ParticlesMode particles;
        private final CloudRenderMode clouds;
        private final GraphicsMode graphics;
        private final boolean entityShadows;
        private final boolean smoothLighting;
        private final int mipmapLevels;
        private final int biomeBlendRadius;
        private final double entityDistanceScaling;

        private PerformanceSnapshot(MinecraftClient client) {
            viewDistance = client.options.getViewDistance().getValue();
            simulationDistance = client.options.getSimulationDistance().getValue();
            particles = client.options.getParticles().getValue();
            clouds = client.options.getClouds().getValue();
            graphics = client.options.getGraphicsMode().getValue();
            entityShadows = client.options.getEntityShadows().getValue();
            smoothLighting = client.options.getSmoothLighting().getValue();
            mipmapLevels = client.options.getMipmapLevels().getValue();
            biomeBlendRadius = client.options.getBiomeBlendRadius().getValue();
            entityDistanceScaling = client.options.getEntityDistanceScaling().getValue();
        }

        private void restore(MinecraftClient client) {
            client.options.getViewDistance().setValue(viewDistance);
            client.options.getSimulationDistance().setValue(simulationDistance);
            client.options.getParticles().setValue(particles);
            client.options.getClouds().setValue(clouds);
            client.options.getGraphicsMode().setValue(graphics);
            client.options.getEntityShadows().setValue(entityShadows);
            client.options.getSmoothLighting().setValue(smoothLighting);
            client.options.getMipmapLevels().setValue(mipmapLevels);
            client.options.getBiomeBlendRadius().setValue(biomeBlendRadius);
            client.options.getEntityDistanceScaling().setValue(entityDistanceScaling);
        }
    }

    private static void renderRainbowHud(net.minecraft.client.gui.DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        String serverOrWorld;
        if (client.getCurrentServerEntry() != null) {
            serverOrWorld = "Server: " + client.getCurrentServerEntry().name;
        } else {
            String worldName = "Singleplayer";
            if (client.getServer() != null) {
                try {
                    worldName = client.getServer().getSaveProperties().getLevelName();
                } catch (Exception ignored) {}
            }
            serverOrWorld = "World: " + worldName;
        }

        String[] lines = {
                "FPS: " + MinecraftClient.getCurrentFps(),
                String.format("XYZ: %.1f / %.1f / %.1f",
                        client.player.getX(), client.player.getY(), client.player.getZ()),
                "Player: " + client.player.getName().getString(),
                serverOrWorld
        };

        int y = 8;
        for (String line : lines) {
            drawRainbowRightAligned(context, client, line, y);
            y += 11;
        }
    }

    private static void drawRainbowRightAligned(
            net.minecraft.client.gui.DrawContext context,
            MinecraftClient client,
            String text,
            int y
    ) {
        int totalWidth = client.textRenderer.getWidth(text);
        int x = client.getWindow().getScaledWidth() - totalWidth - 8;
        float hue = (System.currentTimeMillis() % 6000L) / 6000.0f;

        for (int i = 0; i < text.length(); i++) {
            String character = String.valueOf(text.charAt(i));
            int color = java.awt.Color.HSBtoRGB((hue + i * 0.035f) % 1.0f, 0.85f, 1.0f);
            context.drawTextWithShadow(client.textRenderer, character, x, y, color | 0xFF000000);
            x += client.textRenderer.getWidth(character);
        }
    }

    private static void renderRainbowNametags(WorldRenderContext context) {
        if (!rainbowNametags) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null || context.matrixStack() == null
                || context.consumers() == null) return;

        MatrixStack matrices = context.matrixStack();
        Vec3d cameraPos = context.camera().getPos();
        float tickDelta = context.tickCounter().getTickDelta(true);

        for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
            if (player == client.player || player.isRemoved() || !player.isAlive()) continue;

            Vec3d pos = player.getLerpedPos(tickDelta).add(0.0, player.getHeight() + 0.45, 0.0);
            double distanceSq = client.player.squaredDistanceTo(player);
            if (distanceSq > 64.0 * 64.0) continue;

            matrices.push();
            matrices.translate(pos.x - cameraPos.x, pos.y - cameraPos.y, pos.z - cameraPos.z);
            matrices.multiply(context.camera().getRotation());
            matrices.scale(-0.025f, -0.025f, 0.025f);

            String name = player.getName().getString();
            int width = client.textRenderer.getWidth(name);
            float x = -width / 2.0f;
            float hue = (System.currentTimeMillis() % 5000L) / 5000.0f;

            Matrix4f matrix = matrices.peek().getPositionMatrix();
            for (int i = 0; i < name.length(); i++) {
                String character = String.valueOf(name.charAt(i));
                int color = java.awt.Color.HSBtoRGB((hue + i * 0.045f) % 1.0f, 0.9f, 1.0f);
                client.textRenderer.draw(
                        character, x, 0, color | 0xFF000000, true, matrix,
                        context.consumers(), net.minecraft.client.font.TextRenderer.TextLayerType.SEE_THROUGH,
                        0x50000000, 0xF000F0
                );
                x += client.textRenderer.getWidth(character);
            }
            matrices.pop();
        }
    }
}
