CART3R CLIENT — SOURCE PROJECT v4
Minecraft Java: 1.21.1
Fabric Loader: 0.16.9+
Java: 21
Menu key: Right Shift

REAL GRAPHICS PROFILES ADDED:
FPS Optimizer:
- Render distance: 6 chunks
- Simulation distance: 5 chunks
- Reduced particles
- Fast graphics and fast clouds
- Entity shadows and smooth lighting disabled
- Mipmaps reduced
- Entity render distance reduced

Potato Mode:
- Render distance: 2 chunks
- Simulation distance: 2 chunks
- Minimal particles
- Clouds off
- Fast graphics
- Entity shadows and smooth lighting disabled
- Mipmaps and biome blending set to minimum
- Entity render distance reduced further

When both are enabled, Potato Mode takes priority. When both are disabled,
the mod restores the graphics settings captured before the first profile was enabled.
Settings are saved through Minecraft's options writer.

NOTES:
- This is source code, not a ready-to-install JAR or APK.
- The project has not been compiled or tested in-game. If Gradle reports API/mapping
  errors, the affected method or enum names may need adjustment for the chosen Yarn build.
- FPS gains depend on device, world, mods, and thermal limits. No fixed FPS is guaranteed.
- Player hitboxes, rainbow HUD, and rainbow nametags are still included from v3.

BUILD:
Use Java 21 and Gradle; run `gradle build`. Output JAR should appear in build/libs/.
