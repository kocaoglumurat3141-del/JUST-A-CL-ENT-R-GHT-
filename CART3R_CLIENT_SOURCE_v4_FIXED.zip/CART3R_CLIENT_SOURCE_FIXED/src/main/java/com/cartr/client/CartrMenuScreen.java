package com.cartr.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class CartrMenuScreen extends Screen {
    public CartrMenuScreen() {
        super(Text.literal("CART3R CLIENT"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;
        int left = centerX - 105;
        int top = centerY - 98;

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Player Hitboxes: " + (CartrClient.playerHitboxes ? "ON" : "OFF")),
                button -> {
                    MinecraftClient.getInstance().debugRenderer.toggleShowHitboxes();
                    CartrClient.playerHitboxes = !CartrClient.playerHitboxes;
                    button.setMessage(Text.literal("Player Hitboxes: " +
                            (CartrClient.playerHitboxes ? "ON" : "OFF")));
                }
        ).dimensions(left, top, 210, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Rainbow Player Nametags: " + (CartrClient.rainbowNametags ? "ON" : "OFF")),
                button -> {
                    CartrClient.rainbowNametags = !CartrClient.rainbowNametags;
                    button.setMessage(Text.literal("Rainbow Player Nametags: " +
                            (CartrClient.rainbowNametags ? "ON" : "OFF")));
                }
        ).dimensions(left, top + 25, 210, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Rainbow HUD: " + (CartrClient.rainbowHud ? "ON" : "OFF")),
                button -> {
                    CartrClient.rainbowHud = !CartrClient.rainbowHud;
                    button.setMessage(Text.literal("Rainbow HUD: " +
                            (CartrClient.rainbowHud ? "ON" : "OFF")));
                }
        ).dimensions(left, top + 50, 210, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("FPS Optimizer: " + (CartrClient.fpsOptimizer ? "ON" : "OFF")),
                button -> {
                    CartrClient.fpsOptimizer = !CartrClient.fpsOptimizer;
                    CartrClient.refreshPerformanceSettings();
                    button.setMessage(Text.literal("FPS Optimizer: " +
                            (CartrClient.fpsOptimizer ? "ON" : "OFF")));
                }
        ).dimensions(left, top + 75, 210, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Potato Mode: " + (CartrClient.potatoMode ? "ON" : "OFF")),
                button -> {
                    CartrClient.potatoMode = !CartrClient.potatoMode;
                    CartrClient.refreshPerformanceSettings();
                    button.setMessage(Text.literal("Potato Mode: " +
                            (CartrClient.potatoMode ? "ON" : "OFF")));
                }
        ).dimensions(left, top + 100, 210, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Close"),
                button -> this.close()
        ).dimensions(left, top + 130, 210, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0xC010071B);
        context.fill(this.width / 2 - 120, this.height / 2 - 112,
                this.width / 2 + 120, this.height / 2 + 160, 0xFF281343);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title,
                this.width / 2, this.height / 2 - 103, 0xFFD9B8FF);
        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Purple client menu"),
                this.width / 2, this.height / 2 + 144, 0xFFC4A7E8);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
